package g;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import javax.servlet.http.HttpServlet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class verifyLogin1 extends HttpServlet {
	public static int accountno;
	public static long seconds;
	public static String username;
	private static Scanner y;
	private static Scanner z;
	public static int a = 1;
	public static int zz;
	public static boolean b;
	String f = "C:/Temp2/log2.txt";
	String f11 = "C:/Temp2/logout1.txt";
	private static final Logger _log = LogManager.getLogger(verifyLogin1.class);
	public static boolean m;

	/*
	 * public static int readRecord(int account, String f, String f11, long d) {
	 * accountno = account; int m = 1; String acno = Integer.toString(accountno);
	 * String ds = Long.toString(d); String ID; String t; String ID1; String t1;
	 * String d1; try {
	 *
	 * Date date1 = new Date(); y = new Scanner(new File(f),
	 * StandardCharsets.UTF_8.name()); y.useDelimiter("[,\n]"); z = new Scanner(new
	 * File(f11), StandardCharsets.UTF_8.name()); z.useDelimiter("[,\n]");
	 * System.out.println("Account number is:" + acno); while (y.hasNextLine() ||
	 * z.hasNextLine()) { System.out.println("INSIDE TRY"); ID = y.next(); t =
	 * y.next(); System.out.println(ID); System.out.println(t); ID1 = z.next();//
	 * contains user account no who has logged out t1 = z.next(); d1 = z.next();
	 * System.out.println("INSIDE TRY-1");
	 *
	 * // while (true) { if (ID.equals(acno)) {
	 * System.out.println("acc no to login is  " + acno); if (acno.equals(ID1))// &&
	 * t.equals(t1)) { m = 1; }
	 *
	 * else { m = 0; } } else { m = 1; System.out.println("INSIDE TRY-2"); }
	 *
	 * }
	 *
	 * // } } catch (Exception e) { e.getStackTrace(); e.getMessage(); }
	 * System.out.println("Value of m outside is:" + m); return m;
	 *
	 * }
	 */

	public static boolean checkLogin(int account, String username, String password) {
		accountno = account;
		String acno = Integer.toString(accountno);
		boolean status = false;
		Connection con = GetCon.getCon();
		try {
			// to check the user has logged before 60 seconds
			/*
			 * File file = new File("C:/Temp2/log2.txt");
			 *
			 * BufferedReader br = new BufferedReader(new FileReader(file)); Date date = new
			 * Date(); seconds = date.getTime() / 1000L;
			 * System.out.println("The seconds is :" + seconds); int o;
			 */
			/*
			 * String f1 = "C:/Temp2/log2.txt"; String f2 = "C:/Temp2/logout1.txt";
			 */
			// o = readRecord(accountno, f1, f2, seconds);
			PreparedStatement ps5 = con.prepareStatement("Select @statevalue :=state from NEW1 where accountno=?");
			ps5.setInt(1, accountno);
			ResultSet rs5 = ps5.executeQuery();
			while (rs5.next()) {
				zz = rs5.getInt(1);
			}
			System.out.println("Value of statevalue is" + zz);
			int o = 1;
			/*
			 * { o=1; } else { o=0; }
			 */

			// _log.info("Initiating Login for user : " + accountno);
			PreparedStatement ps = con
					.prepareStatement("Select * from NEW1 where accountno=? and username = ? and password =?");
			ps.setInt(1, accountno);
			ps.setString(2, username);
			ps.setString(3, password);

			ResultSet rs = ps.executeQuery();
			status = rs.next();
			_log.info(String.format("Login %s for user : %d", status ? "Successful" : "not successful", accountno));

			/*
			 * int c = 0;
			 *
			 * m = false; String x = acno.valueOf(m);
			 * System.out.println("Value of b in verifyLogin1.java is" + x);
			 *
			 * // Date today = new Date();
			 *
			 * // time = today.getHours() + ":" + today.getMinutes() + ":" + //
			 * today.getSeconds(); String file1 = "C:/Temp2/log2.txt"; String file21 =
			 * "C:/Temp2/logtime1.txt"; String file22 = "C:/Temp2/log22.csv"; FileWriter fw
			 * = new FileWriter(file1, true); BufferedWriter bw = new BufferedWriter(fw);
			 * PrintWriter pw = new PrintWriter(bw); pw.append(accountno + "," + seconds);
			 * pw.append("\n"); FileWriter fw1 = new FileWriter(file22, true);
			 * BufferedWriter bw1 = new BufferedWriter(fw1); PrintWriter pw1 = new
			 * PrintWriter(bw1); pw1.append(accountno + "," + seconds); pw1.append("\n");
			 * FileWriter fw21 = new FileWriter(file21, true); BufferedWriter bw21 = new
			 * BufferedWriter(fw21); PrintWriter pw21 = new PrintWriter(bw21); String sec =
			 * Long.toString(seconds); pw21.append(sec); pw21.append("\n"); hmap = new
			 * HashMap<Integer, Boolean>(); hmap.put(accountno, false);
			 * System.out.println("Value of the user logged out is(In verifyLogin1.java)" +
			 * hmap);
			 */
			PreparedStatement ps1 = con
					.prepareStatement("UPDATE nm1.new1\r\n" + "SET state = 0\r\n" + "WHERE accountno=?;");
			ps1.setInt(1, accountno);

			int rs1 = ps1.executeUpdate();
			// status = rs1.next();
			System.out.println("Inside verifyLogin1 the status for login is" + rs1);
			/*
			 * FileWriter fw1 = new FileWriter(file, true); BufferedWriter bw1 = new
			 * BufferedWriter(fw1); PrintWriter pw1 = new PrintWriter(bw1);
			 * pw1.append(accountno + "," + username + "," + seconds);
			 */
			/*
			 * String input; int count = 0; while ((input = br.readLine()) != null) {
			 * count++; }
			 *
			 * pw.close(); pw1.close(); pw21.close();
			 */
			// JOptionPane.showMessageDialog(null, "Record Saved");

		} catch (Exception e) {
			_log.error(e);
			// JOptionPane.showMessageDialog(null, "Record not Saved");
		}
		System.out.println("The account no outside function is:" + accountno);
		return status;
	}

	/*
	 * @Override protected void doGet(HttpServletRequest request,
	 * HttpServletResponse response) throws ServletException, IOException {
	 * HttpSession session = request.getSession(); // session.setAttribute("acc",
	 * acno); // System.out.println("Inside HttpServletrequest" + accountno); //
	 * session.setAttribute("s", seconds); // request.setAttribute("acn",
	 * accountno); // request.setAttribute("s", seconds); }
	 */

}

/*
 * private static Scanner x; String filename="C:/Temp2/log2.csv"; public static
 * int readRecord(int accountno,String filename) throws FileNotFoundException,
 * IOException { boolean found=false; BufferedReader br = new BufferedReader(new
 * FileReader("C:/Temp2/log2.csv")); StringTokenizer st; String line; while (
 * (line = br.readLine()) != null ) { String[] values = line.split("/");
 * if(values[searchColumnIndex].equals(searchString)) { resultRow = line; break;
 * } } br.close(); return resultRow;
 *
 *
 * //if(accountno==" " && ) //{ //
 * alert("User cant be logged in as he has logged before 60 sec"); //} return 1;
 * }
 *
 * }
 */